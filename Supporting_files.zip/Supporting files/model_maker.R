list.of.packages <- c("devtools", "bigrquery", "dplyr", "DBI", "ggplot2", "tseries", "quantmod", "forecast", "xts", "timeSeries", "Metrics", "jsonlite")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)

library(devtools)
library(bigrquery)
library(dplyr)
library(DBI)
library(ggplot2)
library(tseries)
library(quantmod)
library(forecast)
library(xts)
library(timeSeries)
library(Metrics)
library(jsonlite)


Models <-function (){
    
    projectid<-'dspd-111111'
    datasetid<-'KSE_dataset'
    bq_conn <-  dbConnect(bigquery(),project = projectid, dataset = datasetid, use_legacy_sql = FALSE)
    bq_auth(email = "dr.farooqarby@gmail.com", use_oob = "TRUE")
    temp <- dplyr::tbl(bq_conn,"kse_dataset")
    data<-collect(temp, kse_dataset)
    data_1<-data

    lambda <- seq(0,1,0.1)
    repeats <- seq(10,50,5)
    networks<- seq(10,60,5)
    
    grid <- expand.grid(lambda = lambda , repeats = repeats, num_networks = networks)
    
    n <- c("./ABL_model.rds" ,"./ABOT_model.rds", "./ACPL_model.rds" , "./AHCL_model.rds" ,"./AICL_model.rds" , "./AKBL_model.rds" , "./APL_model.rds" ,"./ARM_model.rds","./ARPL_model.rds", 
           "./ASRL_model.rds","./ATRL_model.rds","./BAFL_model.rds","./BAHL_model.rds","./BATA_model.rds", "./BNWM_model.rds","./BOP_model.rds","./CHCC_model.rds" , "./COLG_model.rds" , "./DAWH_model.rds", 
           "./DCR_model.rds" ,"./DGKC_model.rds","./EFERT_model.rds","./EFOODS_model.rds" ,"./EFUG_model.rds", "./EFUL_model.rds","./ENGRO_model.rds" ,"./FABL_model.rds" , "./FATIMA_model.rds", "./FCCL_model.rds", 
           "./FEROZ_model.rds", "./FFBL_model.rds" , "./FFC_model.rds" ,"./FML_model.rds", "./GATM_model.rds", "./GHGL_model.rds","./GLAXO_model.rds" ,"./HBL_model.rds" ,"./HCAR_model.rds","./HMB_model.rds",
           "./HUBC_model.rds","./HUMNL_model.rds", "./IBFL_model.rds","./ICI_model.rds","./IDYM_model.rds" ,"./IGIIL_model.rds", "./INDU_model.rds" , "./ISL_model.rds", "./JDWS_model.rds" , "./JGICL_model.rds",
           "./JLICL_model.rds" ,"./JSCL_model.rds","./KAPCO_model.rds", "./KEL_model.rds" ,"./KOHC_model.rds" , "./KTML_model.rds","./LPL_model.rds", "./LUCK_model.rds","./MARI_model.rds","./MCB_model.rds",
           "./MEBL_model.rds","./MLCF_model.rds","./MTL_model.rds","./MUREB_model.rds","./NATF_model.rds", "./NBP_model.rds", "./NCL_model.rds", "./NCPL_model.rds","./NESTLE_model.rds" ,"./NML_model.rds",
           "./NPL_model.rds", "./NRL_model.rds","./OGDC_model.rds","./OLPL_model.rds","./PAEL_model.rds" , "./PAKCEM_model.rds", "./PAKT_model.rds","./PGF_model.rds" ,"./PIBTL_model.rds","./PIOC_model.rds",
           "./PKGP_model.rds","./PKGS_model.rds","./POL_model.rds", "./POML_model.rds","./PPL_model.rds", "./PSEL_model.rds","./PSMC_model.rds","./PSO_model.rds" ,"./PTC_model.rds" ,"./RMPL_model.rds", 
           "./SCBPL_model.rds","./SEARL_model.rds", "./SHEL_model.rds" , "./SHFA_model.rds","./SNBL_model.rds",  "./SNGP_model.rds" , "./SRVI_model.rds","./SSGC_model.rds","./THALL_model.rds" ,"./TRG_model.rds",
           "./UBL_model.rds","./CPPL_model.rds" , "./HASCOL_model.rds","./PICT_model.rds","./SPWL_model.rds",  "./BWCL_model.rds","./CSAP_model.rds","./PMPK_model.rds" , "./HGFA_model.rds" , "./IGIHL_model.rds",
           "./CJPL_model.rds","./ASTL_model.rds","./ATLH_model.rds" , "./GADT_model.rds" , "./INIL_model.rds" , "./AGIL_model.rds" , "./EPCL_model.rds" , "./FHAM_model.rds","./PSX_model.rds" ,"./SYS_model.rds",
           "./UNITY_model.rds","./ASL_model.rds", "./BYCO_model.rds","./GATI_model.rds" , "./GSKCH_model.rds", "./SML_model.rds", "./STJT_model.rds" , "./FCEPL_model.rds", "./AGP_model.rds", "./FFL_model.rds",
           "./LOTCHEM_model.rds" ,"./ANL_model.rds","./HINOON_model.rds","./ILP_model.rds","./YOUW_model.rds")
    
    indexes<- list()
    
    for (i in 2:ncol(data_1)){
      
      print ("Starting")
      forecasted_series<- list()
      X_df <- data_1[i] #Dataframe
      X_vector <- data_1[[i]] #Vector
      X_na_removed <- X_vector[!is.na(X_vector)] # NA removed vector
      X_na_removed_df <- as.data.frame(X_na_removed, col.names = "V1") #NA removed df
      models <- list()
      X_train = X_na_removed_df[1:(nrow(X_na_removed_df)-1),] # Include all values except the last one
      actual <- X_na_removed_df[-(1:length(X_train)),] # Last value 
    
      for (j in 1:nrow(grid)) {
      
        lambda<- grid$lambda[j]
        repeats<- grid$repeats[j]
        num_networks<- grid$num_networks[j]
      
        models[[j]]<-nnetar(X_train, lambda = lambda ,
                                        repeats = repeats,
                                        num_networks = num_networks )
      
      }
      
      rmse <- c()
    
      for (k in 1:length(models)){
      
        model <- models[[k]]
        fcast <- forecast(model, PI=TRUE, h=1, allow.multiplicative.trend = TRUE, biasadj = TRUE)
        forecasted_series <- fcast$mean[1]
        forecasted_series <- as.list(forecasted_series)
        rmse[k] <- rmse (as.numeric(actual) , as.numeric(forecasted_series))
                       
      }
    
      ind <- which.min(rmse)
      indexes <- append(indexes, rmse[ind])
      best_model <- models[[ind]]
      nn<- n[i-1]
      saveRDS(best_model, nn)

    }

    
    return ("DONE!")
}

Models()
  