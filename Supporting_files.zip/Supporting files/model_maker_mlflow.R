list.of.packages <- c("devtools", "base","bigrquery", "dplyr", "DBI", "ggplot2","carrier" ,"mlflow","tseries", "grid","quantmod", "forecast", "xts", "timeSeries", "Metrics", "jsonlite","dbplyr")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)

mlflow::install_mlflow()  
library(mlflow)
library(carrier)
library(devtools)
library(bigrquery)
library(dplyr)
library(DBI)
library(ggplot2)
library(tseries)
library(quantmod)
library(forecast)
library(xts)
library(timeSeries)
library(Metrics)
library(jsonlite)
library(dbplyr)
library(grid)
library(base)

#mlflow_set_tracking_uri("file:///home/ibrahim/DSPD_Project/API/mlruns") # Change that to your own local directory for reproducability

    projectid<-'dspd-111111'
    datasetid<-'KSE_dataset'
    bq_conn <-  dbConnect(bigquery(),project = projectid, dataset = datasetid, use_legacy_sql = FALSE)
    bq_auth(email = "dr.farooqarby@gmail.com", use_oob = "TRUE")
    temp <- dplyr::tbl(bq_conn,"kse_dataset")
    data<-collect(temp, kse_dataset)
    data_1<-data

    forecasted_series = list()
    lambda <- seq(0,1,0.1)
    repeats <- seq(10,50,5)
    networks<- seq(10,60,5)
    
    #data_1[92]
    grid <- expand.grid(lambda = lambda , repeats = repeats, num_networks = networks)
    
    for (i in 1:ncol(data_1)){

      #mlflow_end_run()
      forecasted_series<- list()
      X_df <- data_1[i] #Dataframe
      exp_name <- colnames(X_df)
      
      mlflow_set_experiment(experiment_name = exp_name)
      
      X_vector <- data_1[[i]] #Vector
      X_na_removed <- X_vector[!is.na(X_vector)] # NA removed vector
      X_na_removed_df <- as.data.frame(X_na_removed, col.names = "V1") 
      models <- list()
      X_train = X_na_removed_df[1:(nrow(X_na_removed_df)-1),]
      actual <- X_na_removed_df[-(1:length(X_train)),]
    
      for (j in 1:nrow(grid)) {
      
          lambda <- mlflow_param("lambda", grid$lambda[j], "numeric")
          repeats <- mlflow_param("repeats", grid$repeats[j], "numeric")
          num_networks<- mlflow_param("networks", grid$num_networks[j], "numeric")
          
          with(mlflow_start_run(experiment_id = i-1 ) , {
            
          models[[j]]<-nnetar(X_train, lambda = lambda ,
                                        repeats = repeats,
                                        num_networks = num_networks )
      
          mlflow_log_param("lambda", lambda)
          mlflow_log_param("repeats", repeats)
          mlflow_log_param("networks", num_networks)
        
          actual <- X_na_removed_df[-(1:length(X_train)),]
          rmse <- c()
          forecasted_series<- list()
          model <- models[[j]]
          fcast <- forecast(model, PI=TRUE, h=1, allow.multiplicative.trend = TRUE, biasadj = TRUE)
          forecasted_series <- fcast$mean[1]
          forecasted_series <- as.list(forecasted_series)
          rmse <- rmse (as.numeric(actual) , as.numeric(forecasted_series))
          
          mlflow_log_metric("rmse", rmse)
      
       })
        }
    }
        #mlflow_end_run()  
