list.of.packages <- c("curl", "openssl", "webshot", "stringr", "rvest", "webdriver", "dplyr", "bigrquery", "bigQueryR", "dplyr")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)

library(curl)
library(openssl)
library(webshot)
library(stringr)
library(webdriver)
library(dplyr)
library(bigrquery)
library(bigQueryR)
library(dbplyr)

webshot::install_phantomjs()
library(rvest)



system("phantomjs scrape.js")

webpage <- xml2::read_html("1.html" )
# Extract the URLs
url_ <- webpage %>%
  rvest::html_nodes(xpath = "/html/body/div[6]/div[4]/div[2]/div[2]/div[1]/ul/li[3]/a") %>% 
  rvest::html_attr(name = "href")


link <- url_


data<-function(link){
  
  # Downloading file just to get the name of the csv
  
  download_link <- paste("https://dps.psx.com.pk",link, sep = "")
  str_list <- strsplit(link, '/')[[1]]
  zip_file <- str_list[4]
  download.file(download_link, zip_file)
  zipdf <- unzip(zip_file, list = TRUE)
  
  # getting the csv filename from zip file
  csv_file <- zipdf$Name
  
  # Accessing the csv file via tempfile()
  temp <- tempfile()
  download.file(download_link, temp)
  file <- unz(temp, csv_file)
  
  scrapped_data <- read.csv(file)
  
  stocks_list <- c("ABL" ,"ABOT", "ACPL" , "AHCL" ,"AICL" , "AKBL" , "APL" ,"ARM","ARPL", 
                   "ASRL","ATRL","BAFL","BAHL","BATA", "BNWM","BOP","CHCC" , "COLG" , "DAWH", 
                   "DCR" ,"DGKC","EFERT","EFOODS" ,"EFUG", "EFUL","ENGRO" ,"FABL" , "FATIMA", "FCCL", 
                   "FEROZ", "FFBL" , "FFC" ,"FML", "GATM", "GHGL","GLAXO" ,"HBL" ,"HCAR","HMB",
                   "HUBC","HUMNL", "IBFL","ICI","IDYM" ,"IGIIL", "INDU" , "ISL", "JDWS" , "JGICL",
                   "JLICL" ,"JSCL","KAPCO", "KEL" ,"KOHC" , "KTML","LPL", "LUCK","MARI","MCB",
                   "MEBL","MLCF","MTL","MUREB","NATF", "NBP", "NCL", "NCPL","NESTLE" ,"NML",
                   "NPL", "NRL","OGDC","OLPL","PAEL" , "PAKCEM", "PAKT","PGF" ,"PIBTL","PIOC",
                   "PKGP","PKGS","POL", "POML","PPL", "PSEL","PSMC","PSO" ,"PTC" ,"RMPL", 
                   "SCBPL","SEARL", "SHEL" , "SHFA","SNBL",  "SNGP" , "SRVI","SSGC","THALL" ,"TRG",
                   "UBL","CPPL" , "HASCOL","PICT","SPWL",  "BWCL","CSAP","PMPK" , "HGFA" , "IGIHL",
                   "CJPL","ASTL","ATLH" , "GADT" , "INIL" , "AGIL" , "EPCL" , "FHAM","PSX" ,"SYS",
                   "UNITY","ASL", "BYCO","GATI" , "GSKCH", "SML", "STJT" , "FCEPL", "AGP", "FFL",
                   "LOTCHEM" ,"ANL","HINOON","ILP","YOUW")
  # Getting the stocks of only KSE 100
  
  scrapped_data$SYMBOL_CODE <- gsub("'", '', scrapped_data$SYMBOL_CODE)
  temp_data <- scrapped_data[scrapped_data$SYMBOL_CODE %in% stocks_list,]
  temp_data <- temp_data[,-c(1,3,4,5,7)]
  new_data <- subset(temp_data, !duplicated(subset(temp_data, select= SYMBOL_CODE)))
  return(new_data)
  
}  

dataa<-data(link)

bq_auth(email = "dr.farooqarby@gmail.com",path = "/home/DSPD_project/Web_Scrapper/dspd-111111-4fe50ea1b5ef.json")
  
  
projectid<-'dspd-111111'
datasetid<-'scrapped_dataset'
tableid <- 'scrapped_data'
  

  

data_table = bq_table(project = projectid, dataset = datasetid, table = 'data')
bq_table_create(x = data_table, fields = as_bq_fields(dataa))
bq_table_upload(x = data_table, values = dataa, create_disposition = "CREATE_IF_NEEDED", write_disposition = "WRITE_APPEND")

